var searchData=
[
  ['code',['code',['../struct_shader_info.html#accea55bc0ce5331445d533c743f4aaec',1,'ShaderInfo']]],
  ['color',['color',['../struct_vertex_data.html#a305475959e3c612d733b423f55f16709',1,'VertexData']]]
];
